<?php

namespace App\Http\Controllers\employee\dashboard;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class DashboardController extends Controller
{
    public function index(){
        return view('employee.dashboard.index');
    }
}
