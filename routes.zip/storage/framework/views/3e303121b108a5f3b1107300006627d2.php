<nav id="sidebar" class="sidebar js-sidebar">
    <div class="sidebar-content js-simplebar">
        <a class="sidebar-brand" href="">
            <span class="align-middle" style="font-size: 35px">Zingo Assist</span>
        </a>

        <ul class="sidebar-nav">
            <li class="sidebar-item">
                <a class="sidebar-link"  href="<?php echo e(route('admin.dashboard')); ?>">
                    <i class="align-middle" data-feather="book"></i> <span class="align-middle">Dashboard</span>
                </a>
            </li>
            <li class="sidebar-item">
                <a class="sidebar-link"  href="<?php echo e(route('admin.employee')); ?>">
                    <i class="align-middle" data-feather="book"></i> <span class="align-middle">Employees Info</span>
                </a>
            </li>
            <li class="sidebar-item">
                <a class="sidebar-link"  href="<?php echo e(route('admin.employee_gallery')); ?>">
                    <i class="align-middle" data-feather="book"></i> <span class="align-middle">Employees Gallery</span>
                </a>
            </li>
            <li class="sidebar-item">
                <a class="sidebar-link" href="<?php echo e(route('admin.attendance')); ?>">
                    <i class="align-middle" data-feather="book"></i> <span class="align-middle">Attendance</span>
                </a>
            </li>
            <li class="sidebar-item">
                <a class="sidebar-link" href="<?php echo e(route('admin.lead')); ?>">
                    <i class="align-middle" data-feather="book"></i> <span class="align-middle">Leads</span>
                </a>
            </li>
            <li class="sidebar-item">
                <a class="sidebar-link" href="<?php echo e(route('admin.employees')); ?>">
                    <i class="align-middle" data-feather="book"></i><span class="align-middle">Employee Todo Lists</span>
                </a>
            </li>
            <li class="sidebar-item">
                <a class="sidebar-link" href="<?php echo e(route('admin.contact')); ?>">
                    <i class="align-middle" data-feather="book"></i> <span class="align-middle">Contacts</span>
                </a>
            </li>
            <li class="sidebar-item">
                <a class="sidebar-link" href="<?php echo e(route('admin.gallery')); ?>">
                    <i class="align-middle" data-feather="book"></i> <span class="align-middle">Gallery</span>
                </a>
            </li>
            <li class="sidebar-item">
                <a class="sidebar-link" href="<?php echo e(route('admin.register')); ?>">
                    <i class="align-middle" data-feather="book"></i> <span class="align-middle">New Registration</span>
                </a>
            </li>
        </ul>
    </div>
</nav>
<?php /**PATH C:\Users\hp440\Desktop\Program\working\erp_zingo\resources\views/adminpartials/sidebar.blade.php ENDPATH**/ ?>