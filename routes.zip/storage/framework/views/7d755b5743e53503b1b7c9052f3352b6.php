<?php $__env->startSection('title', 'Profile'); ?>

<?php $__env->startSection('content'); ?>
    <div class="container-fluid p-0">
        <div class="mb-3 row">
            <div class="col-md-6">
                <h1 class="h3 d-inline align-middle">Your Profile</h1>
            </div>
            <div class="col-md-6">
                <a href="<?php echo e(route('employee.profile.create')); ?>" style="float: right" class="btn btn-primary">Add</a>
            </div>
        </div>
        <div class="row">
            <div class="col-md-12">
                <?php if($user->email): ?>
                    <div class="card">
                        <div class="card-header">
                            <h5 class="card-title mb-0">Profile Details</h5>
                        </div>
                        
                        <div class="row">
                            <div class="col-md-6">
                                <?php if($user->picture): ?>
                                    <img src="<?php echo e(asset('template/img/photos/' . $user->picture)); ?>" alt="picture"
                                        class="img-fluid rounded-circle m-2" width="280px" height="280px" />
                                <?php else: ?>
                                    <img src="https://ui-avatars.com/api/?name=<?php echo e($user->name); ?>" alt="picture"
                                        class="img-fluid rounded-circle m-2" width="280px" height="280px" />
                                <?php endif; ?>
                            </div>
                            <div class="col-md-6 align-content-center">
                                <h3><b>Psuedo Name</b> : <?php echo e($user->name); ?></h3>
                                <h3><b>Email</b> : <?php echo e($user->email); ?></h3>
                            </div>
                        </div>
                        <hr>
                        <div class="mx-auto">
                            <p><b>Real Name</b> : <?php echo e($user->real_name); ?></p>
                            <p><b>CNIC</b> : <?php echo e($user->cnic); ?></p>
                            <p><b>Phone</b> : <?php echo e($user->phone); ?></p>
                            <p><b>Date of Brith</b> : <?php echo e($user->dob); ?></p>
                            <p><b>Bank Account</b> : <?php echo e($user->bank_no); ?></p>
                            <p><b>Job Description</b> : <?php echo e($user->jd); ?></p>
                        </div>
                        <div class="card-header">
                            <h5 class="card-title mt-3"></h5>
                        </div>
                        <div class="card-body">
                            <h4>About Me</h4>
                            <p><?php echo e($user->about_me); ?></p>
                        </div>
                    </div>
                <?php else: ?>
                    <div class="alert alert-info">Please set your profile</div>
                <?php endif; ?>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\hp440\Desktop\Program\working\erp_zingo\resources\views/employee/profile/index.blade.php ENDPATH**/ ?>