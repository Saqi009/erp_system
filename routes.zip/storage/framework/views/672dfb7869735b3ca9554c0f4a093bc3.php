<?php $__env->startSection('title', 'Profile'); ?>

<head>
    <style>
        .video-gallery {
            display: flex;
            gap: 20px;
            flex-wrap: wrap;
        }

        .video-item {
            border: 1px solid #ccc;
            padding: 10px;
            width: 320px;
            text-align: center;
        }
    </style>
</head>

<?php $__env->startSection('content'); ?>
    <div class="container-fluid p-0">
        <div class="mb-3 row">
            <div class="col-md-6">
                <h1 class="h3 d-inline align-middle">Videos</h1>
            </div>
            <div class="col-md-6">
                <a href="<?php echo e(route('admin.gallery')); ?>" style="float: right" class="btn btn-primary">Back</a>
            </div>
        </div>
    </div>
    <?php echo $__env->make('partials.alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php if(count($videos) > 0): ?>
        <div class="video-gallery">
            <?php $__currentLoopData = $videos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $video): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div>
                    <button onclick="playFullscreen('video_<?php echo e($video->id); ?>')">
                        <video id="video_<?php echo e($video->id); ?>" width="250" height="220">
                            <source src="<?php echo e(asset('template/videos/' . $video->video)); ?>" type="video/mp4">
                            Your browser does not support the video tag.
                        </video>
                    </button>
                    <form action="<?php echo e(route('admin.gallery.video.destroy', $video)); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field("DELETE"); ?>
                        <input type="submit" class="form-control btn btn-danger" style="float: left;" value="Delete">
                    </form>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    <?php else: ?>
        <div class="alert alert-info">No video found!</div>
    <?php endif; ?>

    <script>
        // Function to play video in fullscreen mode
        function playFullscreen(videoId) {
            var video = document.getElementById(videoId);
            if (video.requestFullscreen) {
                video.requestFullscreen();
            } else if (video.webkitRequestFullscreen) { // Safari compatibility
                video.webkitRequestFullscreen();
            } else if (video.msRequestFullscreen) { // IE11 compatibility
                video.msRequestFullscreen();
            }
            video.play();
        }

        // Function to pause video
        function pauseVideo(videoId) {
            var video = document.getElementById(videoId);
            video.pause();
        }
    </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlayout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\hp440\Desktop\Program\working\erp_zingo\resources\views/admin/gallery/video/index.blade.php ENDPATH**/ ?>