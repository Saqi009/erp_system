<?php $__env->startSection('content'); ?>
    <div class="container-fluid p-0">

        <div class="row">
            <div class="col-12">
                <div class="card p-2">
                    
                    <div class="mt-5 container m-auto ">
                        <h3 id="heading-1" class="mb-3">Todo App</h3>
                        <?php echo $__env->make('partials.alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                        <form action="<?php echo e(route('todo')); ?>" method="post" class="d-flex">
                            <?php echo csrf_field(); ?>
                            <input type="text" placeholder="Enter the task." id="add-input"
                                class="round p-2 gap=3 form-control" name="lists">
                            <input type="submit" value="Add Task" id="btn-submit" class="btn btn-primary ml-2">
                        </form>
                        <div>
                            <?php $__errorArgs = ['lists'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="text-danger"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <?php if(count($tasks) > 0): ?>
                            <table class="table mt-5 table-bordered">
                                <thead>
                                    <tr>
                                        <th class="col-8">Tasks</th>
                                        <th class="text-center">Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $tasks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($task->lists); ?></td>
                                            <td>
                                                <div class="row">
                                                    <div class="col-md-6 text-end">
                                                        <a href="<?php echo e(route('todo.edit', $task)); ?>"
                                                            class="btn btn-primary">Edit</a>
                                                    </div>
                                                    <div class="col-md-3">
                                                        <form action="<?php echo e(route('todo.destroy', $task)); ?>" method="post">
                                                            <?php echo method_field('DELETE'); ?>
                                                            <?php echo csrf_field(); ?>
                                                            <input type="submit" class="btn btn-danger ml-2"
                                                                value="Delete">
                                                        </form>
                                                    </div>
                                                </div>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        <?php else: ?>
                            <div class="alert alert-info">No Records Found!</div>
                        <?php endif; ?>
                    </div>

                </div>
            </div>
        </div>
    </div>
    </div>
    </div>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\hp440\Desktop\Program\working\erp_zingo\resources\views/employee/todo/index.blade.php ENDPATH**/ ?>