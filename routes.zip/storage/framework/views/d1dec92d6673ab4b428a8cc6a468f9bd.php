<?php $__env->startSection('content'); ?>
    <div class="container-fluid p-0">

        <div class="row">
            <div class="col-md-6">
                <h1 class="h3 mb-3">Employee Info</h1>
            </div>
            <div class="col-md-6">
                <a href="<?php echo e(route('admin.employee')); ?>" style="float: right" class="btn btn-primary">Back</a>
            </div>
        </div>

        <div class="row">
            <div class="col-12">
                <div class="card">
                    <?php echo $__env->make('partials.alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <div class="row mb-3">
                        <div class="card-body p-5 col-md-6 mx-auto ">
                            <div class="row">
                                <div class="col-4">
                                    Real Name:
                                </div>
                                <div class="col-8">
                                    <?php echo $employee->real_name ?? '<em>N/A</em>'; ?>

                                </div>
                            </div>
                            <hr>
                            <div class="row">
                                <div class="col-4">
                                    Pseudo Name:
                                </div>
                                <div class="col-8">
                                    <?php echo $employee->name ?? '<em>N/A</em>'; ?>

                                </div>
                            </div>
                            <hr>
                            <div class="row">
                                <div class="col-4">
                                    Date of Birth:
                                </div>
                                <div class="col-8">
                                    <?php echo $employee->dob ?? '<em>N/A</em>'; ?>

                                </div>
                            </div>
                            <hr>

                            <div class="row">
                                <div class="col-4">
                                    Email:
                                </div>
                                <div class="col-8">
                                    <?php echo $employee->email ?? '<em>N/A</em>'; ?>

                                </div>
                            </div>
                            <hr>
                            <div class="row">
                                <div class="col-4">
                                    Phone:
                                </div>
                                <div class="col-8">
                                    <?php echo $employee->phone ?? '<em>N/A</em>'; ?>

                                </div>
                            </div>
                            <hr>
                            <div class="row">
                                <div class="col-4">
                                    CNIC:
                                </div>
                                <div class="col-8">
                                    <?php echo $employee->cnic ?? '<em>N/A</em>'; ?>

                                </div>
                            </div>
                            <hr>
                            <div class="row">
                                <div class="col-4">
                                    Account Number:
                                </div>
                                <div class="col-8">
                                    <?php echo $employee->bank_no ?? '<em>N/A</em>'; ?>

                                </div>
                            </div>
                            <hr>
                            <div class="row">
                                <div class="col-4">
                                    Job Description:
                                </div>
                                <div class="col-8">
                                    <?php echo $employee->jd ?? '<em>N/A</em>'; ?>

                                </div>
                            </div>
                            <hr>
                            <div class="mb-2">
                                <a href="<?php echo e(route('admin.employee.edit', $employee)); ?>" class="btn btn-primary">Edit</a>

                                <form action="<?php echo e(route('admin.employee.destroy', $employee)); ?>" method='post' class="d-inline">
                                    <?php echo method_field('DELETE'); ?>
                                    <?php echo csrf_field(); ?>
                                    <input type="submit" value="Delete" class="btn btn-danger">
                                </form>
                            </div>

                            <a href="<?php echo e(route('admin.employee.password', $employee)); ?>">Change employee password</a>
                        </div>
                        <div class="col-md-6 align-content-center">
                            <?php if($employee->picture): ?>
                                <img src="<?php echo e(asset('template/img/photos/' . $employee->picture)); ?>" alt="picture"
                                    class="img-fluid rounded-circle m-2" width="280px" height="280px" />
                            <?php else: ?>
                                <img src="https://ui-avatars.com/api/?name=<?php echo e($employee->name); ?>" alt="picture"
                                    class="img-fluid rounded-circle m-2" width="280px" height="280px" />
                            <?php endif; ?>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlayout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\hp440\Desktop\Program\working\erp_zingo\resources\views/admin/employee/show.blade.php ENDPATH**/ ?>