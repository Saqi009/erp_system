<?php $__env->startSection('content'); ?>
    <div class="container-fluid p-0">

        <h1 class="h3 mb-3">Edit Task</h1>

        <div class="row">
            <div class="col-12">
                <div class="card p-5">
                    
                    <div class="mt-5 container w-75 m-auto ">
                        <h1 id="heading-1" class="mb-3">Edit Task</h1>
                        <?php echo $__env->make('partials.alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <form action="<?php echo e(route('todo.update', $task)); ?>" method="post" class="d-flex">
                            <?php echo method_field('PATCH'); ?>
                            <?php echo csrf_field(); ?>
                            <input type="text" placeholder="Enter the task." id="add-input"
                                class="round p-2 gap=3 form-control" name="lists"
                                value="<?php echo e(old('lists') ?? $task->lists); ?>">
                            <input type="submit" value="Update" id="btn-submit" class="btn btn-primary ml-2">
                            <a href="<?php echo e(route('todo')); ?>" class="btn btn-secondary">Back</a>
                        </form>
                        <div>
                            <?php $__errorArgs = ['lists'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="text-danger"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                    </div>
                    

                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\hp440\Desktop\ooffice\erp_zingo\resources\views/employee/todo/edit.blade.php ENDPATH**/ ?>