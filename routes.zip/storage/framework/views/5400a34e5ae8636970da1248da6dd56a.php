<?php $__env->startSection('title', 'Profile'); ?>

<head>
    <style>
        .picture {
            display: flex;
            gap: 10px;
            flex-wrap: wrap;
        }

        .picture-box img {
            border-radius: 10px
        }

        .picture-box:hover {
            box-shadow: 1px 1px 2px;
        }

        .picture-box img:hover {
            border-radius: 2px;
        }

        .img-thumbnail {
            cursor: pointer;
        }

        /* Adjusted styles for the modal image */
        #modalImage {
            max-width: 90%;
            /* Adjust max-width as needed */
            max-height: 90%;
            /* Adjust max-height as needed */
            object-fit: contain;
            /* Maintain aspect ratio */
        }
    </style>
</head>

<?php $__env->startSection('content'); ?>
    <div class="container-fluid p-0">
        <div class="mb-3 row">
            <div class="col-md-6">
                <h1 class="h3 d-inline align-middle">Images</h1>
            </div>
            <div class="col-md-6">
                <a href="<?php echo e(route('admin.gallery')); ?>" style="float: right" class="btn btn-primary">Back</a>
            </div>
        </div>
    </div>
    <?php echo $__env->make('partials.alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php if(count($images) > 0): ?>
        <div class="picture">
            <?php $__currentLoopData = $images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pic): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="picture-box mx-auto">
                    <img src="<?php echo e(asset('template/images/' . $pic->image)); ?>" alt="<?php echo e($pic->image); ?>" width="280"
                        height="340" alt="<?php echo e($pic->image); ?>"
                        onclick="openModal('<?php echo e(asset('template/images/' . $pic->image)); ?>')" />
                    <form action="<?php echo e(route('admin.gallery.image.destroy', $pic)); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <input type="submit" class="form-control btn btn-danger" style="float: ledft;" value="Delete">
                    </form>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    <?php else: ?>
        <div class="alert alert-info">No Image Found!</div>
    <?php endif; ?>

    <!-- Modal -->
    <div class="modal fade" id="imageModal" tabindex="-1" aria-labelledby="imageModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-fullscreen">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="imageModalLabel">Image</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body d-flex justify-content-center align-items-center">
                    <img id="modalImage" src="" class="img-fluid" alt="Large Image">
                </div>
            </div>
        </div>
    </div>



    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    
    <script>
        function openModal(imageSrc) {
            $('#modalImage').attr('src', imageSrc);
            $('#imageModal').modal('show');
        }
    </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlayout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\hp440\Desktop\Program\working\erp_zingo\resources\views/admin/gallery/image/index.blade.php ENDPATH**/ ?>