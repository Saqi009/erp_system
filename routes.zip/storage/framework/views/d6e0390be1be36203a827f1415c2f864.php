<script src="<?php echo e(asset('template/js/custom.js')); ?>"></script>
<script src="<?php echo e(asset('template/js/app.js')); ?>"></script>
<?php /**PATH C:\Users\hp440\Desktop\ooffice\erp_zingo\resources\views/adminpartials/scripts.blade.php ENDPATH**/ ?>