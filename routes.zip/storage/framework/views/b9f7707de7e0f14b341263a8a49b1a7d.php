<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>ERP Mail</title>
</head>
<body>
    <p><b>Name</b> : <?php echo e($mail_data['name']); ?></p>
    <p><b>Department</b> : <?php echo e($mail_data['department']); ?></p>
    <p><b>message</b> : <?php echo e($mail_data['message']); ?></p>
</body>
</html>
<?php /**PATH C:\Users\hp440\Desktop\Program\working\erp_zingo\resources\views/employee/email/show.blade.php ENDPATH**/ ?>