<nav class="navbar navbar-expand navbar-light navbar-bg">
    <a class="sidebar-toggle js-sidebar-toggle">
        <i class="hamburger align-self-center"></i>
    </a>

    <div class="navbar-collapse collapse">
        <ul class="navbar-nav navbar-align">
            <li class="nav-item dropdown">
                <a class="nav-icon dropdown-toggle d-inline-block d-sm-none" href="#" data-bs-toggle="dropdown">
                    <i class="align-middle" data-feather="settings"></i>
                </a>

                <a class="nav-link dropdown-toggle d-none d-sm-inline-block" href="#" data-bs-toggle="dropdown">
                    
                    <span class="text-dark"><?php echo e(Auth::user()->name); ?></span>
                </a>
                <div class="dropdown-menu dropdown-menu-end">
                    
                    <form action="<?php echo e(route('logout')); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <input type="submit" class="dropdown-item" value="Log out" >
                    </form>
                </div>
            </li>
        </ul>
    </div>
</nav>
<?php /**PATH C:\Users\hp440\Desktop\working\erp_zingo\resources\views/partials/topbar.blade.php ENDPATH**/ ?>