<?php $__env->startSection('content'); ?>
    <div class="container-fluid p-0">

        <div class="row mb-3">
            <div class="col-md-6">
                <h1 class="h3 mb-3"></h1>
            </div>
            <div class="col-md-6">
                <a href="<?php echo e(route('attendance')); ?>" class="btn btn-primary" style="float: right">Back</a>
            </div>
        </div>
        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-header">
                        <h1>Your Attendance</h1>
                    </div>
                    <?php echo $__env->make('partials.alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <div class="card-body">
                        <?php if(count($attendances) > 0): ?>
                            <table class="table">
                                <thead>
                                    <tr>
                                        <th>Sr No.</th>
                                        <th>Date</th>
                                        <th>Time</th>
                                        <th>Status</th>
                                        <th>Leave Reason</th>
                                    </tr>
                                </thead>
                                <?php $__currentLoopData = $attendances; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $attendance): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tbody>
                                        <tr>
                                            <td><?php echo e($loop->iteration); ?></td>
                                            <td><?php echo $attendance->date ?? '<em>N/A</em>'; ?></td>
                                            <td><?php echo $attendance->created_at ? $attendance->created_at->format('g:i A') : '<em>N/A</em>'; ?></td>
                                            <td><?php echo $attendance->status ?? '<em>N/A</em>'; ?></td>
                                            <td><?php echo $attendance->leave_reason ?? '<em>N/A</em>'; ?></td>
                                        </tr>
                                    </tbody>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </table>
                        <?php else: ?>
                            <div class="alert alert-danger">No attendance found!</div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\hp440\Desktop\Program\working\erp_zingo\resources\views/employee/attendance/yourattendance.blade.php ENDPATH**/ ?>