<script src="<?php echo e(asset('template/js/custom.js')); ?>"></script>
<script src="<?php echo e(asset('template/js/app.js')); ?>"></script>
<?php /**PATH C:\Users\hp440\Desktop\working\erp_zingo\resources\views/partials/scripts.blade.php ENDPATH**/ ?>