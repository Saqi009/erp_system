<?php $__env->startSection('content'); ?>
    <div class="container-fluid p-0">

        <h1 class="h3 mb-3">Attendance</h1>

        <form action="<?php echo e(route('admin.attendance')); ?>" method="get" class="row mb-4">
            <div class="col-7">
                <input type="text" class="form-control" id="search" name="search" placeholder="Search">
            </div>
            <div class="col-5">
                <input type="submit" name="submit" value="Search" class="btn btn-primary">
            </div>
        </form>
        
        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-body">
                        <?php if(count($attendances) > 0): ?>
                            <table class="table">
                                <thead>
                                    <th>Name</th>
                                    <th>Floor Manager</th>
                                    <th>Work Shift</th>
                                    <th>Date</th>
                                    <th>Time</th>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $attendances; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $attendance): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($attendance->name); ?></td>
                                            <td><?php echo e($attendance->floor_manager); ?></td>
                                            <td><?php echo e($attendance->work_shift); ?></td>
                                            <td><?php echo e($attendance->date); ?></td>
                                            <td><?php echo e($attendance->created_at->setTimezone('GMT+5')->format('h:i:s A')); ?></td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        <?php else: ?>
                            <div class="alert alert-info">No Attandance Record Found!</div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlayout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\hp440\Desktop\Program\working\erp_zingo\resources\views/admin/attendance/index.blade.php ENDPATH**/ ?>