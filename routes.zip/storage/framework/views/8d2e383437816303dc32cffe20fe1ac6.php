<?php $__env->startSection('content'); ?>
    <div class="container-fluid p-0">

        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-body">

                        <div class="row">
                            <div class="col-6">
                                <h2 class="m-0">All Lead</h2>
                            </div>
                            <div class="col-6 ">
                                <a href="<?php echo e(route('admin.lead')); ?>" style="float: right;"
                                    class="btn btn-outline-primary">Back</a>
                            </div>
                        </div>
                        
                        <div class="row">
                            <div class="col-md-10 mx-auto">
                                <hr>
                                <div class="row">
                                    <div class="col-4">
                                        Name:
                                    </div>
                                    <div class="col-8">
                                        <?php echo e($lead->name); ?>

                                    </div>
                                </div>
                                <hr>
                                <div class="row">
                                    <div class="col-4">
                                        Email:
                                    </div>
                                    <div class="col-8">
                                        <?php echo e($lead->email ?? '<em>N/A</em>'); ?>

                                    </div>
                                </div>
                                <hr>
                                <div class="row">
                                    <div class="col-4">
                                        Phone:
                                    </div>
                                    <div class="col-8">
                                        <?php echo e($lead->phone_number); ?>

                                    </div>
                                </div>
                                <hr>
                                <div class="row">
                                    <div class="col-4">
                                        Timezone:
                                    </div>
                                    <div class="col-8">
                                        <?php echo e($lead->time_zone); ?>

                                    </div>
                                </div>
                                <hr>
                                <div>
                                    <label for="remark">Remarks: </label>
                                    <textarea name="remark" id="remark" cols="30" rows="6" class="form-control"
                                        placeholder="Client Remarks Here" readonly><?php echo e(old('remark') ?? $lead->remark); ?></textarea>
                                </div>
                            </div>


                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlayout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\hp440\Desktop\ooffice\erp_zingo\resources\views/admin/lead/show.blade.php ENDPATH**/ ?>