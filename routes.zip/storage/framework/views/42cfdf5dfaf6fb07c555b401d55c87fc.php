<footer class="footer">
    <div class="container-fluid">
        <div class="row text-muted">
            <div class="col-12">
                <h4 class="m-0 text-center"> Zingo Assist &#174</h4>

            </div>
        </div>
    </div>
</footer>
<?php /**PATH C:\Users\hp440\Desktop\ooffice\erp_zingo\resources\views/adminpartials/footer.blade.php ENDPATH**/ ?>