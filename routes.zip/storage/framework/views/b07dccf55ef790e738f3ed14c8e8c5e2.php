<?php $__env->startSection('title', 'Profile'); ?>

<head>
    <style>
        .file-gallery {
            display: flex;
            flex-wrap: wrap;
            gap: 2px;
        }

        .file-item {
            border: 1px solid #ccc;
            padding: 10px;
            width: 300px;
            text-align: center;
        }
    </style>
</head>

<?php $__env->startSection('content'); ?>
    <div class="container-fluid p-0">
        <div class="mb-3 row">
            <div class="col-md-6">
                <h1 class="h3 d-inline align-middle">Files</h1>
            </div>
            <div class="col-md-6">
                <a href="<?php echo e(route('employee.gallery')); ?>" style="float: right" class="btn btn-primary">Back</a>
            </div>
        </div>
    </div>
    <div>
        <?php echo $__env->make('partials.alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php if(count($files) > 0): ?>
            <div class="file-gallery">
                <?php $__currentLoopData = $files; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $doc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="file-item">
                        <p><?php echo e($doc->file); ?></p>
                        <a href="<?php echo e(asset('template/files/' . $doc->file)); ?>" target="_blank">View</a>
                        <a href="<?php echo e(asset('template/files/' . $doc->file)); ?>" download>Download</a>
                        <form action="<?php echo e(route('employee.gallery.file.destroy', $doc)); ?>" method="post">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <input type="submit" class="text-center"
                                style="border: none; background: none; cursor: pointer; color: red;" value="Delete">
                        </form>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        <?php else: ?>
            <div class="alert alert-info">No Image Found!</div>
        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\hp440\Desktop\Program\working\erp_zingo\resources\views/employee/gallery/file/index.blade.php ENDPATH**/ ?>