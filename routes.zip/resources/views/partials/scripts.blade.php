<script src="{{ asset('template/js/custom.js') }}"></script>
<script src="{{ asset('template/js/app.js') }}"></script>


<script>
    $(":input").inputmask();
</script>



